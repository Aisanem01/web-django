from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return HttpResponse ('Hello, World!')

def rinata(request):
    return HttpResponse('Hello,Rinata!')

def instagramAccount(request, name):
    return HttpResponse(f"This is {name.capitalize()}'s instagram account")